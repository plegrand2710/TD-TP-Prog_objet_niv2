package carnetAdresse;

import javax.swing.*;
import java.awt.*;

public class ContactGUI {
    public static void main(String[] args) {
        // Création de la fenêtre principale
        JFrame frame = new JFrame("Edit");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLayout(new BorderLayout());

        // Création de la barre de menus
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Edit");
        menuBar.add(menu);
        frame.setJMenuBar(menuBar);

        // Panel pour l'image et les boutons de navigation
        JPanel imagePanel = new JPanel(new BorderLayout());

        // Boutons flèches
        JButton leftButton = new JButton("<");
        leftButton.setPreferredSize(new Dimension(50, 30));
        JButton rightButton = new JButton(">");
        rightButton.setPreferredSize(new Dimension(50, 30));

        // Chargement de l'image
        JLabel imageLabel = new JLabel();
        ImageIcon imageIcon = new ImageIcon("./images/Client1.png"); // Remplacez par le chemin de votre image
        Image scaledImage = imageIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(scaledImage));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Ajout des composants au panel d'image
        imagePanel.add(leftButton, BorderLayout.WEST);
        imagePanel.add(imageLabel, BorderLayout.CENTER);
        imagePanel.add(rightButton, BorderLayout.EAST);

        frame.add(imagePanel, BorderLayout.NORTH);

        // Panel pour les champs de formulaire avec barre de défilement
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Ajout des étiquettes et champs de texte
        String[] labels = {
            "Numéro", "Nom", "Prénom", "Téléphone", "Adresse",
            "Code Postal", "Email", "Métier", "Situation"
        };
        String[] values = {
            "2", "Einstein", "Franck", "+4523568", "???",
            "98846", "e=mc^2@hotmail", "physicien", "décédé"
        };

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.weightx = 0.3;
            formPanel.add(new JLabel(labels[i]), gbc);

            gbc.gridx = 1;
            gbc.weightx = 0.7;
            formPanel.add(new JTextField(values[i]), gbc);
        }

        JScrollPane scrollPane = new JScrollPane(formPanel);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Panel pour les boutons de navigation
        JPanel buttonPanel = new JPanel(new GridLayout(1, 7, 5, 5));
        String[] buttonLabels = {"Début", "Suivant", "Préc.", "Fin", "Milieu", "Nouv...", "Save"};
        for (String label : buttonLabels) {
            buttonPanel.add(new JButton(label));
        }
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}