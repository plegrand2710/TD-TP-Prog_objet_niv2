/**
 * 
 */
/**
 * 
 */
module TD1 {
	requires java.desktop;
}
